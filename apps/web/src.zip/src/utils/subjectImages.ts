// apps/web/src/utils/subjectImages.ts
import type { Course } from '@cvpro/shared/types'

/** --------------------------------------------------------
 * Canonical subjects → images  (curated for clarity & legibility)
 * ------------------------------------------------------- */
export const SUBJECT_IMAGE_MAP: Record<string, string> = {
  // Core academics
  mathematics:       'https://images.pexels.com/photos/6238050/pexels-photo-6238050.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  science:           'https://images.pexels.com/photos/8325716/pexels-photo-8325716.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  english:           'https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  history:           'https://images.pexels.com/photos/27352428/pexels-photo-27352428.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  'computer science':'https://images.pexels.com/photos/3861976/pexels-photo-3861976.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  'foreign languages':'https://images.pexels.com/photos/9334542/pexels-photo-9334542.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  arts:              'https://images.pexels.com/photos/7302100/pexels-photo-7302100.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  'social studies':  'https://images.pexels.com/photos/8617974/pexels-photo-8617974.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  business:          'https://images.pexels.com/photos/8145328/pexels-photo-8145328.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  engineering:       'https://images.pexels.com/photos/6285153/pexels-photo-6285153.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  law:               'https://images.pexels.com/photos/5669619/pexels-photo-5669619.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  medicine:          'https://images.pexels.com/photos/7723510/pexels-photo-7723510.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  music:             'https://images.pexels.com/photos/17249492/pexels-photo-17249492/free-photo-of-close-up-of-a-music-sheet-and-a-violin.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  philosophy:        'https://images.pexels.com/photos/26887007/pexels-photo-26887007.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  psychology:        'https://images.pexels.com/photos/8378740/pexels-photo-8378740.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  sociology:         'https://images.pexels.com/photos/5710984/pexels-photo-5710984.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',

  // Quant/Science specifics
  economics:         'https://images.pexels.com/photos/5980871/pexels-photo-5980871.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  biology:           'https://images.pexels.com/photos/11210346/pexels-photo-11210346.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  chemistry:         'https://images.pexels.com/photos/8326459/pexels-photo-8326459.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  physics:           'https://images.pexels.com/photos/3845162/pexels-photo-3845162.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  finance:           'https://images.pexels.com/photos/28165814/pexels-photo-28165814.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',

  // Dedicated canonicals
  statistics:        'https://images.pexels.com/photos/7054368/pexels-photo-7054368.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
  'deep learning':   'https://images.pexels.com/photos/17485705/pexels-photo-17485705.jpeg?auto=compress&cs=tinysrgb&w=1400&fit=crop',
}

export const FALLBACK_COURSE_IMAGE =
  'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?q=80&w=1400&auto=format&fit=crop'

/** --------------------------------------------------------
 * Aliases → canonical subjects
 * ------------------------------------------------------- */
export const SUBJECT_ALIASES: Record<string, string[]> = {
  mathematics: [
    'math','algebra','linear algebra','fractions','decimals',
    'calculus','discrete math','combinatorics','graphs','equations','functions','pca',
    'quant','optimization'
  ],

  statistics: [
    'statistics','statistical','probability','hypothesis test','hypothesis testing',
    'p-values','p value','confidence interval','ab testing','a/b testing','a b testing',
    'time series','forecasting','econometrics','regression','anova',
    'data analysis','pandas','dataframe','data frames',
    'data visualization','visualization','matplotlib',
    'charts','plots','dashboard','dashboards',
    'business analytics','kpis','kpi'
  ],

  'deep learning': [
    'deep learning','neural network','neural networks','cnn','rnn','lstm',
    'transformer','attention','pytorch','keras','autoencoder','gpt'
  ],

  'computer science': [
    'data structures','algorithms','time complexity','python','javascript','typescript',
    'react','node','graphql','sql','docker','kubernetes','cloud fundamentals','git',
    'ml','machine learning',
    'computer vision','nlp','rag','prompt engineering'
  ],

  physics: ['mechanics','motion','forces','thermodynamics','optics','electricity','magnetism'],
  chemistry: ['stoichiometry','periodic table','reactions','equilibrium'],
  biology: ['cells','genetics','evolution'],

  english: [
    'literature','writing','composition','reading','grammar',
    'public speaking','presentation','presentations','writing skills','communication'
  ],

  arts: ['art','drawing','painting','design','ui/ux','ux','ui','wireframes','prototyping'],

  'foreign languages': ['german a1','kiswahili','vocabulary','french','spanish'],

  business: ['marketing','seo','social media','product management','project management','entrepreneurship'],

  finance: ['accounting','personal finance','corporate finance'],

  economics: ['microeconomics','macroeconomics'],
}

/** --------------------------------------------------------
 * Priority so fine-grained buckets win over broad categories
 * ------------------------------------------------------- */
export const SUBJECT_PRIORITY = [
  'deep learning',
  'statistics',
  'computer science',
  'mathematics',
  'physics',
  'chemistry',
  'biology',
  'economics',
  'finance',
  'english',
  'foreign languages',
  'arts',
  'business',
]

/** --------------------------------------------------------
 * Utilities
 * ------------------------------------------------------- */
const resolveBackendPath = (url: string | undefined, backendUrl?: string) => {
  if (!url) return ''
  if (url.startsWith('/')) return (backendUrl ?? '').replace(/\/+$/, '') + url
  return url
}

// Accept a looser course shape so TS is happy and we can read subject/category safely.
type CourseLoose = Partial<Course> & {
  subject?: string
  category?: string
  image?: string
  thumbnail_url?: string
  thumb?: string
  description?: string
  title?: string
  level?: string
}

/** --------------------------------------------------------
 * Main picker
 * ------------------------------------------------------- */
export function pickImageForCourse(c: CourseLoose, backendUrl?: string): string {
  // 1) Prefer an explicit image provided by the API/course object
  const direct = resolveBackendPath(c.image || c.thumbnail_url || c.thumb, backendUrl)
  if (direct) return direct

  // 2) Build a searchable "haystack" from common text fields
  const hay = [
    c.subject,
    c.category,
    c.level,
    c.title,
    c.description,
  ].filter(Boolean).join(' ').toLowerCase()

  // 3) Priority-based matching against canonicals and aliases
  for (const key of SUBJECT_PRIORITY) {
    if (!SUBJECT_IMAGE_MAP[key]) continue
    const aliases = SUBJECT_ALIASES[key] || []
    if (hay.includes(key) || aliases.some(a => hay.includes(a))) {
      return SUBJECT_IMAGE_MAP[key]
    }
  }

  // 4) Last chance: scan all canonicals (in case you add ones not in PRIORITY)
  for (const key of Object.keys(SUBJECT_IMAGE_MAP)) {
    if (hay.includes(key)) return SUBJECT_IMAGE_MAP[key]
  }
  for (const [canonical, aliases] of Object.entries(SUBJECT_ALIASES)) {
    if (aliases.some(a => hay.includes(a))) return SUBJECT_IMAGE_MAP[canonical]
  }

  // 5) Fallback
  return FALLBACK_COURSE_IMAGE
}
