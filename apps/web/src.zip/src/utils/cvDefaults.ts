import type { CvDraft, CvSectionKey } from '@cvpro/shared/types';

export const defaultSectionOrder: CvSectionKey[] = [
  'summary',
  'skills',
  'experience',
  'education',
  'projects',
  'certifications',
  'extras',
];

export const defaultSectionVisibility = defaultSectionOrder.reduce(
  (acc, key) => {
    acc[key] = true;
    return acc;
  },
  {} as Record<CvSectionKey, boolean>
);

const sectionKeySet = new Set<CvSectionKey>(defaultSectionOrder);

export const normalizeSectionOrder = (
  order?: CvSectionKey[] | null,
  fallbackOrder: CvSectionKey[] = defaultSectionOrder
): CvSectionKey[] => {
  const source = Array.isArray(order) ? order : [];
  const normalized: CvSectionKey[] = [];
  const seen = new Set<CvSectionKey>();

  source.forEach((key) => {
    if (!sectionKeySet.has(key) || seen.has(key)) return;
    seen.add(key);
    normalized.push(key);
  });

  fallbackOrder.forEach((key) => {
    if (seen.has(key)) return;
    seen.add(key);
    normalized.push(key);
  });

  return normalized;
};

export const normalizeSectionVisibility = (
  visibility?: Partial<Record<CvSectionKey, boolean>> | null
): Record<CvSectionKey, boolean> => {
  const normalized = { ...defaultSectionVisibility };
  if (!visibility) return normalized;

  defaultSectionOrder.forEach((key) => {
    if (typeof visibility[key] === 'boolean') {
      normalized[key] = visibility[key] as boolean;
    }
  });

  return normalized;
};

const templateThemeDefaults: Record<string, Record<string, string>> = {
  'modern-sidebar': {
    primary: '#0f172a',
    sidebarBg: '#0f172a',
    sidebarText: '#f8fafc',
    accent: '#38bdf8',
  },
  'bold-header': {
    primary: '#0f172a',
    headerBg: '#0f172a',
    headerText: '#ffffff',
    accent: '#38bdf8',
  },
  'modern-teal': { primary: '#0f766e', accent: '#0d9488', sectionBg: '#f0fdfa' },
  'modern-sidebar-blue': {
    primary: '#1d4ed8',
    sidebarBg: '#1d4ed8',
    sidebarText: '#eff6ff',
    accent: '#93c5fd',
  },
};

export function normalizeDraft(draft: CvDraft): CvDraft {
  const templateDefaults = templateThemeDefaults[draft.templateId] || {};

  return {
    ...draft,
    sectionOrder: normalizeSectionOrder(draft.sectionOrder),
    sectionVisibility: normalizeSectionVisibility(draft.sectionVisibility),
    basics: {
      ...(draft.basics || ({} as any)),
      name: draft.basics?.name || '',
      headline: draft.basics?.headline || '',
      email: draft.basics?.email || '',
      phone: draft.basics?.phone || '',
      location: draft.basics?.location || '',
      links: draft.basics?.links || [],
      photoUrl: draft.basics?.photoUrl || '',
    },
    skills: draft.skills || [],
    experience: draft.experience || [],
    education: draft.education || [],
    projects: draft.projects || [],
    certifications: draft.certifications || [],
    extras: {
      languages: [],
      interests: [],
      ...draft.extras,
    },
    typography: {
      baseFontSize: 14,
      h1Size: 28,
      h2Size: 13,
      h3Size: 11,
      bodySize: 14,
      lineHeight: 1.48,
      fontFamily: 'Inter, system-ui, Arial',
      ...(draft.typography || {}),
    },
    formatting: {
      textColor: '#0f172a',
      mutedTextColor: '#475569',
      linkColor: '#0f766e',
      ...(draft.formatting || {}),
    },
    templateTheme: {
      primary: '#0f172a',
      ...templateDefaults,
      ...(draft.templateTheme || {}),
    },
    richText: {
      ...(draft.richText || {}),
    },
    coverLetter: {
      subject: draft.coverLetter?.subject || '',
      greeting: draft.coverLetter?.greeting || '',
      body: draft.coverLetter?.body || '',
      closing: draft.coverLetter?.closing || '',
    },
    aiMeta: {
      ...(draft.aiMeta || {}),
    },
    generationMeta: {
      ...(draft.generationMeta || {}),
    },
    meta: {
      isDemoSeeded: Boolean(draft.meta?.isDemoSeeded),
      hasImportedCv: Boolean(draft.meta?.hasImportedCv),
      importedAt: draft.meta?.importedAt,
      importMode: draft.meta?.importMode,
    },
  };
}
