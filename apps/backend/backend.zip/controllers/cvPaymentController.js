import {
  createCvPaystackOrder,
  initCvMpesaPayment,
  confirmCvMpesaPayment,
  getCvMpesaPaymentStatus,
  handleCvMpesaCallback,
  verifyCvPaystackPayment,
  getCvExportEntitlement,
  ensureCvExportEntitlement,
} from '../services/cvPaymentService.js';
import {
  CVPRO_EXPORT_PRICE_USD,
  MPESA_KES_AMOUNT,
  PAYSTACK_KES_AMOUNT,
  PAYSTACK_KES_AMOUNT_MINOR,
} from '../constants/cvPaymentPricing.js';

function resolveError(res, error) {
  const status = error?.statusCode || 500;
  return res.status(status).json({
    message: error?.message || 'Unexpected server error',
    error: error?.message || 'Unexpected server error',
    code: error?.code || 'CV_PAYMENT_ERROR',
    ...(error?.providerMessage ? { providerMessage: error.providerMessage } : {}),
  });
}

export async function getCvPaymentConfig(_req, res) {
  return res.json({
    usdAmount: CVPRO_EXPORT_PRICE_USD,
    paystackKesAmount: PAYSTACK_KES_AMOUNT,
    paystackKesAmountMinor: PAYSTACK_KES_AMOUNT_MINOR,
    mpesaKesAmount: MPESA_KES_AMOUNT,
  });
}

export async function initMpesa(req, res) {
  try {
    const { phone, action, entitlementKey } = req.body || {};
    const forwardedProto = req.headers['x-forwarded-proto'];
    const proto = Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto || req.protocol || 'http';
    const host = req.headers['x-forwarded-host'] || req.get('host');
    const requestBaseUrl = host ? `${proto}://${host}` : null;
    const out = await initCvMpesaPayment({ userId: req.user.id, phone, requestBaseUrl, action, entitlementKey });
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function confirmMpesa(req, res) {
  try {
    const { transactionId, checkoutRequestId, mpesaReceipt } = req.body || {};
    const out = await confirmCvMpesaPayment({
      userId: req.user.id,
      transactionId,
      checkoutRequestId,
      mpesaReceipt,
    });
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function mpesaStatus(req, res) {
  try {
    const transactionId = req.query?.transactionId || req.body?.transactionId;
    const checkoutRequestId = req.query?.checkoutRequestId || req.body?.checkoutRequestId;
    const out = await getCvMpesaPaymentStatus({
      userId: req.user.id,
      transactionId,
      checkoutRequestId,
    });
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function createPaystackOrder(req, res) {
  try {
    const { callbackUrl } = req.body || {};
    if (!callbackUrl) return res.status(400).json({ error: 'callbackUrl is required' });
    const out = await createCvPaystackOrder({ userId: req.user.id, callbackUrl });
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function verifyPaystack(req, res) {
  try {
    const out = await verifyCvPaystackPayment({ userId: req.user.id, reference: req.params.reference });
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function getEntitlement(req, res) {
  try {
    const out = await getCvExportEntitlement(req.user.id, req.query?.entitlementKey || req.query?.key);
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function ensureEntitlement(req, res) {
  try {
    const out = await ensureCvExportEntitlement({ userId: req.user.id, entitlementKey: req.body?.entitlementKey || req.query?.entitlementKey });
    return res.status(200).json(out);
  } catch (error) {
    return resolveError(res, error);
  }
}

export async function mpesaCallback(req, res) {
  try {
    await handleCvMpesaCallback(req.body);
  } catch (error) {
    console.error('[cv/mpesa/callback] processing error', {
      message: error?.message,
      code: error?.code,
    });
  }

  // Daraja expects 200 even when processing fails; retries can otherwise duplicate callbacks.
  return res.status(200).json({ ok: true });
}
